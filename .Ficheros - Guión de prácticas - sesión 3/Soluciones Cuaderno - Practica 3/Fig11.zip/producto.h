/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2016-2017
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// producto.h
//
/***************************************************************************/

#ifndef PRODUCTO
#define PRODUCTO

int multiplica (int, int);
int divide (int, int);

#endif
