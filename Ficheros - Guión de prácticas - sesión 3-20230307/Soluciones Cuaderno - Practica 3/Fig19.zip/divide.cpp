/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2016-2017
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// divide.cpp
//
/***************************************************************************/

using namespace std;

/*********************************************************************/

int divide (int a, int b)
{
   return (a/b); 
}

/*********************************************************************/
